import React from 'react'
import Hero from"../../component/Hero/Hero";
import Sponsors from '../../component/Sponsors/Sponsors';
import AboutUs from '../../component/AboutHome/AboutHome';
import Courses from '../../component/Courses/Courses';

const Home = () => {
  return (
    <div className="container">
      <Hero/>
      <Sponsors/>
      <AboutUs/>
      <Courses/>
    </div>
  )
}

export default Home