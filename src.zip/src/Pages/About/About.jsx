import React from 'react'

const About = () => {
  return (
    <div>About our Organization</div>
  )
}

export default About