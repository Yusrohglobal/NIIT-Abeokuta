import './App.css';
import Header from "./component/Navbar/Navbar"
// import Home from "./Pages/Home/Home";
import Router from './Router';
import Footer from "./component/Footer/Footer";
function App() {
  return (
    <div className="App">
      <Header/>
      <Router/>
      <Footer/>
      {/* <Home/> */}
    </div>
  );
}

export default App;
